-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2021 at 03:28 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stockbarang`
--

-- --------------------------------------------------------

--
-- Table structure for table `keluar`
--

CREATE TABLE `keluar` (
  `idkeluar` int(11) NOT NULL,
  `idbarang` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `penerima` varchar(25) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `keluar`
--

INSERT INTO `keluar` (`idkeluar`, `idbarang`, `tanggal`, `penerima`, `qty`) VALUES
(1, 3, '2021-02-05 06:46:13', 'lisa', 10),
(2, 9, '2021-02-05 10:34:50', 'Putri', 10),
(3, 14, '2021-02-07 06:08:57', 'Putri', 5),
(4, 2, '2021-02-07 11:34:08', 'lisa', 2),
(6, 12, '2021-06-03 17:34:51', 'Paijo', 5),
(7, 3, '2021-07-30 00:29:50', 'aaa', 1);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `iduser` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`iduser`, `nama`, `password`) VALUES
(2, 'rizki@gmail.com', '123'),
(3, 'putri@ymail.com', '12345'),
(4, 'maylisa@yahoo.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `masuk`
--

CREATE TABLE `masuk` (
  `idmasuk` int(11) NOT NULL,
  `idbarang` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `keterangan` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `masuk`
--

INSERT INTO `masuk` (`idmasuk`, `idbarang`, `tanggal`, `keterangan`, `qty`) VALUES
(2, 2, '2021-02-04 19:53:40', 'ahmadd', 2),
(3, 1, '2021-02-04 19:55:02', 'lisa', 2),
(4, 3, '2021-02-05 06:12:24', 'maylisa', 1),
(5, 1, '2021-02-05 06:12:52', 'maylisa', 1),
(6, 9, '2021-02-05 10:34:17', 'Putri', 3),
(8, 11, '2021-02-06 17:29:17', 'lisa', 2),
(10, 13, '2021-02-06 17:32:19', 'lisa', 11),
(11, 2, '2021-02-07 11:14:19', 'rizki', 3),
(12, 11, '2021-06-03 15:30:22', 'maylisa', 50),
(13, 12, '2021-06-03 15:31:21', 'maylisa', 5),
(15, 17, '2021-07-30 00:55:16', 'kiki', 10),
(17, 3, '2021-07-30 01:23:44', 'lisa', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE `pesan` (
  `idpesan` int(11) NOT NULL,
  `idbarang` int(11) NOT NULL,
  `jumlahpesan` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `biayapesan` int(11) NOT NULL,
  `biayasimpan` int(11) NOT NULL,
  `eoq` int(11) NOT NULL,
  `atas` int(11) NOT NULL,
  `bawah` int(11) NOT NULL,
  `frekuensi` int(11) NOT NULL,
  `daurulang` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pesan`
--

INSERT INTO `pesan` (`idpesan`, `idbarang`, `jumlahpesan`, `tanggal`, `biayapesan`, `biayasimpan`, `eoq`, `atas`, `bawah`, `frekuensi`, `daurulang`) VALUES
(50, 9, 24000, '2021-07-29 22:57:40', 2000, 100, 980, 27084, 4880, 24, 209),
(51, 12, 24000, '2021-07-29 22:52:33', 2000, 100, 980, 96000000, 960000, 24, 15),
(52, 2, 23, '2021-07-29 23:22:22', 1990, 100, 30, 2000000, 4000, 1, 231),
(53, 11, 15, '2021-07-30 00:23:18', 1455, 73, 24, 43650, 600, 1, 596);

-- --------------------------------------------------------

--
-- Table structure for table `plan`
--

CREATE TABLE `plan` (
  `idplan` int(11) NOT NULL,
  `idbarang` int(11) NOT NULL,
  `jumlahpesan` int(11) NOT NULL,
  `biayapesan` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `frekuensi` int(11) NOT NULL,
  `bulan` varchar(55) NOT NULL,
  `bulan2` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `plan`
--

INSERT INTO `plan` (`idplan`, `idbarang`, `jumlahpesan`, `biayapesan`, `total`, `frekuensi`, `bulan`, `bulan2`) VALUES
(6, 9, 122, 111, 13542, 2, '01 Januari', '08 Agustus'),
(8, 12, 24000, 2000, 48000000, 24, '01 Januari', '02 Febuary'),
(9, 2, 100, 10000, 1000000, 2, '02 Febuary', ''),
(10, 11, 15, 1455, 21825, 1, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `idbarang` int(11) NOT NULL,
  `namabarang` varchar(50) NOT NULL,
  `deskripsi` varchar(50) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`idbarang`, `namabarang`, `deskripsi`, `stock`) VALUES
(2, 'babycough', 'Tidak Konsinasi', 2),
(3, 'paramex sk', 'Konsinasi', 1),
(9, 'Pil Kb Andalan Biru', 'Tidak Konsinasi', 1),
(10, 'panadol', 'Tidak Konsinasi', 12),
(11, 'Esepuluh', 'Tidak Konsinasi', 60),
(12, 'Supertetra', 'Tidak Konsinasi', 10),
(15, 'Komix Obh', 'Tidak Konsinasi', 20),
(18, 'sangobion syr', 'Tidak Konsinasi', 20);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `role` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `role`) VALUES
(1, 'admin gudang', 'admingudang', 'admingudang'),
(2, 'adminorder', 'adminorder', 'adminorder'),
(3, 'manajer', 'manajer', 'manajer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `keluar`
--
ALTER TABLE `keluar`
  ADD PRIMARY KEY (`idkeluar`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`iduser`);

--
-- Indexes for table `masuk`
--
ALTER TABLE `masuk`
  ADD PRIMARY KEY (`idmasuk`);

--
-- Indexes for table `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`idpesan`);

--
-- Indexes for table `plan`
--
ALTER TABLE `plan`
  ADD PRIMARY KEY (`idplan`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`idbarang`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `keluar`
--
ALTER TABLE `keluar`
  MODIFY `idkeluar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `iduser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `masuk`
--
ALTER TABLE `masuk`
  MODIFY `idmasuk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `pesan`
--
ALTER TABLE `pesan`
  MODIFY `idpesan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `plan`
--
ALTER TABLE `plan`
  MODIFY `idplan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `idbarang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
